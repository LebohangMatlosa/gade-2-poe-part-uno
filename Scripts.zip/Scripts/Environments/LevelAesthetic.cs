using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelAesthetic : MonoBehaviour
{
    public float intLeft;
    public float intRight;

    public static float left =-3.5f;
    public static float right = 3.5f;

    // Update is called once per frame
    void Update()
    {
        intLeft = left;
        intRight = right;
        
    }
}
