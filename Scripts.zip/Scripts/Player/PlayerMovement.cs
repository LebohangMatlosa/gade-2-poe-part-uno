using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float charSpeed = 6;
    public float horizontalSpeed = 5;
    
    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.left * Time.deltaTime * charSpeed, Space.World);
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            
             transform.Translate(Vector3.left * Time.deltaTime * horizontalSpeed);
            
            
        }
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {

            transform.Translate(Vector3.left * Time.deltaTime * horizontalSpeed * -1);
            
          
        }
       /* if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
        {

        }
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
        {

        }*/
    }
}
